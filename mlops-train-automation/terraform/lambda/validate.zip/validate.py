import json
import boto3
from datetime import datetime

def lambda_handler(event, context):
    """
    Lambda функція для валідації даних перед тренуванням моделі
    """
    print("🔍 Валідація даних...")
    
    # Отримуємо параметри з event
    source = event.get('source', 'unknown')
    commit = event.get('commit', 'unknown')
    timestamp = datetime.now().isoformat()
    
    print(f"📊 Параметри валідації:")
    print(f"   Source: {source}")
    print(f"   Commit: {commit}")
    print(f"   Timestamp: {timestamp}")
    
    # Симуляція валідації даних
    validation_results = {
        "status": "success",
        "data_quality": "good",
        "sample_count": 1000,
        "features_count": 10,
        "missing_values": 0,
        "outliers_detected": 5,
        "validation_score": 0.95
    }
    
    print(f"✅ Валідація завершена:")
    print(f"   Статус: {validation_results['status']}")
    print(f"   Якість даних: {validation_results['data_quality']}")
    print(f"   Кількість зразків: {validation_results['sample_count']}")
    print(f"   Кількість ознак: {validation_results['features_count']}")
    print(f"   Відсутні значення: {validation_results['missing_values']}")
    print(f"   Викиди: {validation_results['outliers_detected']}")
    print(f"   Оцінка валідації: {validation_results['validation_score']}")
    
    # Повертаємо результат для наступного кроку
    return {
        "statusCode": 200,
        "body": {
            "validation_passed": True,
            "validation_results": validation_results,
            "source": source,
            "commit": commit,
            "timestamp": timestamp,
            "next_step": "log_metrics"
        }
    }
