import json
import boto3
from datetime import datetime

def lambda_handler(event, context):
    """
    Lambda функція для логування метрик після тренування моделі
    """
    print("📈 Логування метрик...")
    
    # Отримуємо результати валідації з попереднього кроку
    validation_results = event.get('validation_results', {})
    source = event.get('source', 'unknown')
    commit = event.get('commit', 'unknown')
    timestamp = datetime.now().isoformat()
    
    print(f"📊 Параметри логування:")
    print(f"   Source: {source}")
    print(f"   Commit: {commit}")
    print(f"   Timestamp: {timestamp}")
    
    # Симуляція метрик тренування
    training_metrics = {
        "model_accuracy": 0.92,
        "model_precision": 0.89,
        "model_recall": 0.91,
        "model_f1_score": 0.90,
        "training_time_seconds": 45,
        "validation_score": validation_results.get('validation_score', 0.95),
        "model_size_mb": 2.5,
        "training_samples": validation_results.get('sample_count', 1000),
        "features_used": validation_results.get('features_count', 10)
    }
    
    print(f"✅ Метрики збережено:")
    print(f"   Точність моделі: {training_metrics['model_accuracy']:.2%}")
    print(f"   Precision: {training_metrics['model_precision']:.2%}")
    print(f"   Recall: {training_metrics['model_recall']:.2%}")
    print(f"   F1-score: {training_metrics['model_f1_score']:.2%}")
    print(f"   Час тренування: {training_metrics['training_time_seconds']} сек")
    print(f"   Розмір моделі: {training_metrics['model_size_mb']} MB")
    
    # Симуляція збереження в CloudWatch Logs
    try:
        cloudwatch = boto3.client('logs')
        log_group_name = '/aws/lambda/mlops-training'
        
        # Створюємо лог групу якщо не існує
        try:
            cloudwatch.create_log_group(logGroupName=log_group_name)
        except cloudwatch.exceptions.ResourceAlreadyExistsException:
            pass
        
        # Створюємо лог стрим
        log_stream_name = f"training-{commit}-{int(datetime.now().timestamp())}"
        try:
            cloudwatch.create_log_stream(
                logGroupName=log_group_name,
                logStreamName=log_stream_name
            )
        except cloudwatch.exceptions.ResourceAlreadyExistsException:
            pass
        
        # Відправляємо лог
        log_events = [{
            'timestamp': int(datetime.now().timestamp() * 1000),
            'message': json.dumps({
                "event_type": "training_completed",
                "metrics": training_metrics,
                "source": source,
                "commit": commit,
                "timestamp": timestamp
            })
        }]
        
        cloudwatch.put_log_events(
            logGroupName=log_group_name,
            logStreamName=log_stream_name,
            logEvents=log_events
        )
        
        print(f"📝 Метрики збережено в CloudWatch Logs: {log_group_name}/{log_stream_name}")
        
    except Exception as e:
        print(f"⚠️ Помилка збереження в CloudWatch: {e}")
    
    # Повертаємо результат
    return {
        "statusCode": 200,
        "body": {
            "metrics_logged": True,
            "training_metrics": training_metrics,
            "source": source,
            "commit": commit,
            "timestamp": timestamp,
            "pipeline_status": "completed"
        }
    }
